export function validerEmail(champ) {
    const valeur = champ.value.trim();
    if (valeur === "") {
      afficherMessageErreur(champ, "Email est obligatoire");
      return false;
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valeur)) {
      afficherMessageErreur(champ, "Email n'est pas valide");
      return false;
    }
    return true;
  }
 
 