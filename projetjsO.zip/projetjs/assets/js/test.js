// const todo = new Map();

// // Tableau des apprenants
// const apprenants = [
//     { idApp: 1, nom: 'Cheikh', prenom: 'Diop', email: 'sy@gmail.com', stats: 'present', img: 'diop.png',idRef:'1', idPromo: 1 },
//     { idApp: 2, nom: 'Aïcha', prenom: 'Ndiaye', email: 'sy@gmail.com', stats: 'present', img: 'diop.png',idRef:'1' , idPromo: 2},
//     { idApp: 3, nom: 'Aïcha', prenom: 'Ndiaye', email: 'sy@gmail.com', stats: 'present', img: 'diop.png',idRef:'1', idPromo: 3 }
// ];





// todo.set("apprenant", apprenants);
// todo.set("utilisateur", { 
//     idUser: 2, 
//     nom: 'bon jour', 
//     prenom: 'diop', 
//     mdp: false, 
//     time: '14:30',
//     img: 'diop.png',
//     sexe: 'F',
//     dateNaissance: '10-09-2024',
//     lieuNaissance: 'Pikine'
// });

// todo.set("promotions", { 
//     idPromo: 3, 
//     title: 'p5', 
//     libeller: 'promotion 5', 
//     dateDebut: 5, 
//     dateFin: 10 
// });
// todo.set("referent", { 
//     idRef: 3, 
//     nomRef:'Dev Web' 
    
// });
// todo.set("Promo_Ref", { 
//     idPromo_Ref:4,
//     idPromo: 3, 
//     idRef: 3
    
// });

