let profile = document.querySelector('.header .profile');

document.querySelector('#user-btn').onclick = () => {
   profile.classList.toggle('active');
   search.classList.remove('active');
}

let toggleBtn = document.getElementById('toggle-btn');
let body = document.body;
let darkMode = localStorage.getItem('dark-mode');

const enableDarkMode = () => {
   toggleBtn.classList.replace('fa-sun', 'fa-moon');
   body.classList.add('dark');
   localStorage.setItem('dark-mode', 'enabled');
}

const disableDarkMode = () => {
   toggleBtn.classList.replace('fa-moon', 'fa-sun');
   body.classList.remove('dark');
   localStorage.setItem('dark-mode', 'disabled');
}

if (darkMode === 'enabled') {
   enableDarkMode();
}

toggleBtn.onclick = (e) => {
   darkMode = localStorage.getItem('dark-mode');
   if (darkMode === 'disabled') {
      enableDarkMode();
   } else {
      disableDarkMode();
   }
}



function pope() {
   return window.location.href = '#popupdate';

}
// console.log(pope());
const DB = {
   etudiants: [
      {
         id_etudiant: 1,
         image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
         prenom: "Sarr",
         nom: "Doudou",
         telephone: "771221903",
         date_naissance: "2023-02-01",
         numero_carte_identite: "222222222222",
         sexe: "M",
         lieuNaissance: "Thies",
         referentiel: 'Dev Data',
         id_promo: 1
      },
      {
         id_etudiant: 2,
         image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
         prenom: "Cisse",
         nom: "BAba",
         telephone: "771230978",
         date_naissance: "1999-05-15",
         email:"",
         numero_carte_identite: "000000000",
         sexe: "F",
         lieu_naissance: "Dakar",
         referentiel: 'Dev Data',
         id_promo: 2
      },
      {
         id_etudiant: 3,
         image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
         prenom: "Kane",
         nom: "Karim",
         telephone: "771230978",
         date_naissance: "1999-05-15",
         numero_carte_identite: "11111111111",
         sexe: "F",
         lieu_naissance: "Dakar",
         referentiel: 'Ref Dig',
         id_promo: 2
      },
      {
         id_etudiant: 4,
         image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
         prenom: "warr",
         nom: "Abdou",
         telephone: "771221903",
         date_naissance: "2023-02-01",
         numero_carte_identite: "222222222222",
         sexe: "M",
         lieuNaissance: "Thies",
         referentiel: 'AWS',
         id_promo: 1
      },
      {
         id_etudiant: 5,
         image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
         prenom: "Cisse",
         nom: "cheikh",
         telephone: "771230978",
         date_naissance: "1999-05-15",
         numero_carte_identite: "000000000",
         sexe: "F",
         lieu_naissance: "Dakar",
         referentiel: 'Dev Web',
         id_promo: 2
      },
      {
         id_etudiant: 6,
         image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
         prenom: "Ibou",
         nom: "Ba",
         telephone: "771230978",
         date_naissance: "1999-05-15",
         numero_carte_identite: "11111111111",
         sexe: "F",
         lieu_naissance: "Dakar",
         referentiel: 'Dev Web',
         id_promo: 2
      }
   ],
   promotions: [
      {
         id_promo: 1,
         libelle: "Promotion 2023",
         id_referentiel: 1
      },
      {
         id_promo: 2,
         libelle: "Promotion 2022",
         id_referentiel: 2
      }
   ],
   referentiels: [
      {
         nom: "Informatique",
         id_referentiel: 1,
         id_promo: 1,
         etat: "actif"
      },
      {
         nom: "Biologie",
         id_referentiel: 2,
         id_promo: 2,
         etat: "actif"
      }
   ]
};

// console.log(DB);



const btnNouvelAp = document.getElementById("BtnNouvelAp");
const prenom = document.getElementById('Prenom');
const nom = document.getElementById('Nom');
const telephone = document.getElementById('Telephone');
const dateNaissance = document.getElementById('DateNaissance');
const cni = document.getElementById('Cni');
const sexe = document.getElementById('Sexe');
const email = document.getElementById('Email');
const lieuNaissance = document.getElementById('LieuNaissance');
const referentiel = document.getElementById('Id_referentiel');
const promo = document.getElementById('Id_promo');
const image = document.querySelector('#image');
const imageEtudiant = document.getElementById("imageEtudiant");



function afficherMessageErreur(champ, message) {
   const messageErreur = document.createElement("div");
   messageErreur.classList.add("erreur-message");
   messageErreur.textContent = message;
   messageErreur.style.color = "red";
   champ.parentNode.appendChild(messageErreur);
}








function validerNomPrenom(champ, nomChamp) {
   const valeur = champ.value.trim();
   if (valeur === "") {
      afficherMessageErreur(champ, nomChamp + " est obligatoire");
      return false;
   } else if (!/^[a-zA-Z]{5,20}$/.test(valeur)) {
      afficherMessageErreur(champ, nomChamp + " doit contenir uniquement des lettres (minimum 5 caractères et maximum 20 caractères)");
      return false;
   }
   return true;
}
function validerTelephone(champ) {
   const valeur = champ.value.trim();
   if (valeur === "") {
      afficherMessageErreur(champ, "Téléphone est obligatoire");
      return false;
   } else if (!/^\d{9}$/.test(valeur)) {
      afficherMessageErreur(champ, "Téléphone doit contenir exactement 9 chiffres");
      return false;
   }
   return true;
}

function validerCNI(champ) {
   const valeur = champ.value.trim();
   if (valeur === "") {
      afficherMessageErreur(champ, "N° CNI est obligatoire");
      return false;
   } else if (!/^\d{1,16}$/.test(valeur)) {
      afficherMessageErreur(champ, "N° CNI doit contenir uniquement des chiffres (maximum 16 chiffres)");
      return false;
   }
   return true;
}

function validerLieuNaissance(champ) {
   const valeur = champ.value.trim();
   if (valeur === "") {
      afficherMessageErreur(champ, "Lieu de Naissance est obligatoire");
      return false;
   } else if (!/^[a-zA-Z]+$/.test(valeur)) {
      afficherMessageErreur(champ, "Lieu de Naissance doit contenir uniquement des lettres");
      return false;
   }
   return true;
}

// Fonction pour valider l'adresse email
function validerEmail(champ) {
   const valeur = champ.value.trim();
   if (valeur === "") {
      afficherMessageErreur(champ, "Email est obligatoire");
      return false;
   } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(valeur)) {
      afficherMessageErreur(champ, "Email n'est pas valide");
      return false;
   }
   return true;
}


image.addEventListener("input", () => {
   imageEtudiant.src = image.value;
});

btnNouvelAp.addEventListener('click', (e) => {
   e.preventDefault();

   // Supprimer les messages d'erreur précédents
   const messagesErreurs = document.querySelectorAll(".erreur-message");
   messagesErreurs.forEach(function (message) {
      message.remove();
   });




   // Valider chaque champ du formulaire
   const nomValide = validerNomPrenom(document.getElementById("Nom"), "Nom");
   const prenomValide = validerNomPrenom(document.getElementById("Prenom"), "Prénom");
   const telephoneValide = validerTelephone(document.getElementById("Pelephone"));
   const cniValide = validerCNI(document.getElementById("Cni"));
   const lieuNaissanceValide = validerLieuNaissance(document.getElementById("LieuNaissance"));
   const emailValide = validerEmail(document.getElementById("Email"));


   if (nomValide && prenomValide && telephoneValide && cniValide && lieuNaissanceValide && emailValide) {


      const nouvelAp = {
         id_etudiant: DB.etudiants.length + 1,
         image: image.value,
         prenom: prenom.value,
         nom: nom.value,
         telephone: telephone.value,
         date_naissance: dateNaissance.value,
         numero_carte_identite: cni.value,
         sexe: sexe.value,
         email: email.value,
         lieuNaissance: lieuNaissance.value,
         referentiel: referentiel.value,
         promo: promo.value
      };

      DB.etudiants.push(nouvelAp);
      console.log(DB);
      afficherApprenants();
   }

})












const tableauApprenants = document.querySelector(".line5 tbody");

function gestionApprenants(DB) {





let img = document.getElementById('img');


let clickCounter = 0; // Compteur pour suivre le nombre de clics sur le bouton de tri

// Fonction pour inverser l'ordre du tri
const reverseSortOrder = () => {
  clickCounter++;
  if (clickCounter % 2 === 0) {
    return 'desc'; // Ordre décroissant pour chaque deuxième clic
  } else {
    return 'asc'; // Ordre croissant pour chaque premier clic
  }
};

// Fonction pour trier les apprenants en fonction de l'ordre spécifié
const sortApprenants = (order) => {
  const sortedApprenants = DB.etudiants.slice().sort((a, b) => {
    const nomA = a.nom.toUpperCase();
    const nomB = b.nom.toUpperCase();
    if (order === 'asc') {
      return nomA.localeCompare(nomB);
    } else if (order === 'desc') {
      return nomB.localeCompare(nomA);
    }
  });
  return sortedApprenants;
};

// Écouter le clic sur le bouton de tri
img.addEventListener('click', (e) => {
  const sortOrder = reverseSortOrder(); // Obtenir l'ordre de tri inversé
  const sortedApprenants = sortApprenants(sortOrder); // Trier les apprenants
  DB.etudiants = sortedApprenants; // Mettre à jour la liste des apprenants triés
  afficherApprenants(); // Afficher les apprenants triés
});




// Fonction pour trier les apprenants en fonction de l'ordre spécifié et de la page actuelle
const sortApprenantsPage = (order, page) => {
   const debut = (page - 1) * apprenantsParPage;
   const fin = debut + apprenantsParPage;
   const apprenantsPage = DB.etudiants.slice(debut, fin);
   const sortedApprenants = apprenantsPage.sort((a, b) => {
     const nomA = a.nom.toUpperCase();
     const nomB = b.nom.toUpperCase();
     if (order === 'asc') {
       return nomA.localeCompare(nomB);
     } else if (order === 'desc') {
       return nomB.localeCompare(nomA);
     }
   });
   return sortedApprenants;
 };
 
 // Écouter le clic sur le bouton de tri
 toggleBtn.addEventListener('click', (e) => {
   const sortOrder = reverseSortOrder(); // Obtenir l'ordre de tri inversé
   const sortedApprenants = sortApprenantsPage(sortOrder, pageActuelle); // Trier les apprenants de la page actuelle
   DB.etudiants.splice((pageActuelle - 1) * apprenantsParPage, apprenantsParPage, ...sortedApprenants); // Mettre à jour les apprenants dans la base de données
   afficherApprenants(); // Afficher les apprenants triés
 });
 







   let tableauGlobalInitial = [...DB.etudiants];
let ancienneTailleSaisie = 0; 
document.getElementById('searchGlobal').addEventListener('input', (e) => {
2
   let valeurSaisie = e.target.value.trim();
   let nouvelleTailleSaisie = valeurSaisie.length;

  
   if (nouvelleTailleSaisie > 2) {
      const tableFilter = DB.etudiants.filter((item) => {
         return (
            item.nom.toLowerCase().includes(valeurSaisie.toLowerCase()) ||
            item.prenom.toLowerCase().includes(valeurSaisie.toLowerCase())
         );
      });

     
      DB.etudiants = tableFilter;

      afficherApprenants();
   }
   else if (nouvelleTailleSaisie === 1) {
      DB.etudiants = [...tableauGlobalInitial];
      generatePaginationLinks();
   }
   else if (nouvelleTailleSaisie === 0) {
    

      DB.etudiants = [...tableauGlobalInitial];

      afficherApprenants();
      generatePaginationLinks();
   }

   ancienneTailleSaisie = nouvelleTailleSaisie;
});

   let casesCochees = [];

   function afficherApprenants() {
      tableauApprenants.innerHTML = "";

      DB.etudiants.forEach(function (apprenant, key) {
         const nouvelleLigne = document.createElement("tr");
         nouvelleLigne.classList.add("line");

         const cellules = ["image", "nom", "prenom", "email", "sexe", "telephone", "referentiel"];
         cellules.forEach(function (prop) {
            const nouvelleCellule = document.createElement("td");
            nouvelleCellule.classList.add("bloc");
            const nouvelleDiv = document.createElement("div");
            nouvelleDiv.classList.add("col-bas");
            if (prop === "image") {
               const imgElement = document.createElement("img");
               imgElement.classList.add("profile-image");
               imgElement.src = apprenant[prop];
               imgElement.alt = "Photo de l'apprenant";
               nouvelleDiv.appendChild(imgElement);
            } else {
               nouvelleDiv.textContent = apprenant[prop];
            }
            nouvelleCellule.appendChild(nouvelleDiv);
            nouvelleLigne.appendChild(nouvelleCellule);
         });
// modification
               const celluleActions = document.createElement("td");
               celluleActions.classList.add("bloc");
               const divActions = document.createElement("div");
               const udapte = document.createElement("div");
               udapte.addEventListener('click',()=>{
                  console.log('p');
                  console.log(key);


function chargerDonneesEtudiant(etudiant) {

   document.getElementById('prenom').value = etudiant.prenom;
   document.getElementById('nom').value = etudiant.nom;
   document.getElementById('email').value = etudiant.email;
   document.getElementById('telephone').value = etudiant.telephone;
   document.getElementById('sexe').value = etudiant.sexe;
   document.getElementById('dateNaissance').value = etudiant.date_naissance;
   document.getElementById('lieuNaissance').value = etudiant.lieu_naissance;
   document.getElementById('cni').value = etudiant.numero_carte_identite;
   document.getElementById('id_referentiel').value = etudiant.referentiel;
   document.getElementById('id_promo').value = etudiant.id_promo;

   console.log()
}

afficherApprenants(   document.getElementById('prenom').value = etudiant.prenom);


function modifierEtudiant() {
   const prenomValue = document.getElementById('prenom').value;
   const nomValue = document.getElementById('nom').value;
   const emailValue = document.getElementById('email').value;
   const telephoneValue = document.getElementById('telephone').value;
   const sexeValue = document.getElementById('sexe').value;
   const dateNaissanceValue = document.getElementById('dateNaissance').value;
   const lieuNaissanceValue = document.getElementById('lieuNaissance').value;
   const cniValue = document.getElementById('cni').value;
   const referentielValue = document.getElementById('id_referentiel').value;
   const promoValue = document.getElementById('id_promo').value;

 
   etudiant.prenom = prenomValue;
   etudiant.nom = nomValue;
   etudiant.email = emailValue;
   etudiant.telephone = telephoneValue;
   etudiant.sexe = sexeValue;
   etudiant.date_naissance = dateNaissanceValue;
   etudiant.lieu_naissance = lieuNaissanceValue;
   etudiant.numero_carte_identite = cniValue;
   etudiant.referentiel = referentielValue;
   etudiant.id_promo = promoValue;

   chargerDonneesEtudiant(etudiant);
}

console.log('ok');

console.log(document.querySelector('.oeil'));



const NnomValide = validerNomPrenom(document.getElementById("nom"), "Nom");
const NprenomValide = validerNomPrenom(document.getElementById("prenom"), "Prénom");
const NtelephoneValide = validerTelephone(document.getElementById("telephone"));
const NcniValide = validerCNI(document.getElementById("cni"));
const NlieuNaissanceValide = validerLieuNaissance(document.getElementById("lieuNaissance"));
const NemailValide = validerEmail(document.getElementById("Email"));

               })
               udapte.innerHTML='<img width="25" height="25" src="https://img.icons8.com/ultraviolet/40/create-new.png" alt="create-new"/>';
               udapte.classList.add('upd');



               
               divActions.classList.add("col-haut");

            //   transfert commenece ici
                      const checkbox = document.createElement("input");
                      checkbox.classList.add('trans');
                      checkbox.type = "checkbox";
                      checkbox.value = apprenant.referentiel; 
                      const referentielOptionId = apprenant.referentiel.replace(" ", "_") + "_option"; 

                      checkbox.addEventListener("change", function (event) {
                     // Mettre à jour le tableau des cases cochées
                     if (event.target.checked) {
                        casesCochees.push(event.target.value);
                        // casesCochees =[...event.target.value];
                        // Masquer l'option correspondante
                        const referentielOption = document.getElementById(referentielOptionId);
                        if (referentielOption) {
                           referentielOption.style.display = "none";
                        }
                     } else {
                        casesCochees = casesCochees.filter(value => value !== event.target.value);
                        // Afficher l'option correspondante
                        const referentielOption = document.getElementById(referentielOptionId);
                        if (referentielOption) {
                           referentielOption.style.display = "";
                        }
                     }
                      console.log("Cases cochées :", casesCochees);
                      });

                        const labelCheckbox = document.createElement("label");
                        labelCheckbox.appendChild(checkbox);

                        divActions.appendChild(labelCheckbox);
                        divActions.appendChild(udapte);
                        celluleActions.appendChild(divActions);
                        nouvelleLigne.appendChild(celluleActions);

                        tableauApprenants.appendChild(nouvelleLigne);
               });
   }

                   document.getElementById("transferButton").addEventListener("click", function () {
                        const selectedReferentiel = document.getElementById("referentielSelectionne").value;
                        if (selectedReferentiel) {
                        
                           casesCochees.forEach(id => {
                              const etudiant = DB.etudiants.find(student => student.referentiel === id);
                              if (etudiant) {
                                 etudiant.referentiel = selectedReferentiel;
                              }
                           });
                           console.log("Cases cochées transférées avec le référentiel :", selectedReferentiel, casesCochees);
                           // Réafficher les apprenants avec les mises à jour
                           afficherApprenants();
                        } else {
                           console.log("Veuillez sélectionner un référentiel.");
                        }
                        casesCochees = [];
                      });

                   
// termine ici
                     afficherApprenants();
                     
                  }


                  gestionApprenants(DB);

                  
// const tableauApprenants = document.querySelector(".line5 tbody");


function afficherApprenants() {
   tableauApprenants.innerHTML = "";

   // Parcourir tous les apprenants dans DB.etudiants
   DB.etudiants.forEach(function (apprenant) {
      const nouvelleLigne = document.createElement("tr");
      nouvelleLigne.classList.add("line");

   
      const cellules = ["image", "nom", "prenom", "email", "sexe", "telephone", "referentiel"];
      cellules.forEach(function (prop) {
         const nouvelleCellule = document.createElement("td");
         nouvelleCellule.classList.add("bloc");
         const nouvelleDiv = document.createElement("div");

   ;

         nouvelleDiv.classList.add("col-bas");
         nouvelleDiv.innerHTML = `<input type="text" value="hhhh" >`;
        
         if (prop === "image") {
            
            const imgElement = document.createElement("img");
            imgElement.classList.add("profile-image");
         
            imgElement.src = apprenant[prop];
            imgElement.alt = "Photo de l'apprenant"; 
            nouvelleDiv.appendChild(imgElement);
         } else {
            nouvelleDiv.textContent = apprenant[prop];
         }
         nouvelleCellule.appendChild(nouvelleDiv);
         nouvelleLigne.appendChild(nouvelleCellule);
      });

   
      const celluleActions = document.createElement("td");
    
      celluleActions.classList.add("bloc");

      const divActions = document.createElement("div");
      divActions.classList.add("col-haut");
      const checkbox = document.createElement("input");
      checkbox.setAttribute("type", "checkbox");
      const labelCheckbox = document.createElement("label");
      labelCheckbox.setAttribute("for", "my-checkbox-" + apprenant.id_etudiant);
      divActions.appendChild(checkbox);
      divActions.appendChild(labelCheckbox);
      celluleActions.appendChild(divActions);
      nouvelleLigne.appendChild(celluleActions);

      // Ajouter la nouvelle ligne au tableau
      tableauApprenants.appendChild(nouvelleLigne);
   });
}

afficherApprenants();









document.addEventListener('DOMContentLoaded', () => {
   let pageActuelle = 1;
   const apprenantsParPage = 2; // Nombre d'apprenants à afficher par page
   const tableauApprenants = document.querySelector(".line5 tbody");
   let tableauGlobalInitial = [...DB.etudiants];

   // Fonction pour afficher les apprenants de la page actuelle
   function afficherApprenants() {
     tableauApprenants.innerHTML = "";

     const debut = (pageActuelle - 1) * apprenantsParPage;
     const fin = debut + apprenantsParPage;
     const apprenantsPage = DB.etudiants.slice(debut, fin);

     apprenantsPage.forEach(function (apprenant) {
       const nouvelleLigne = document.createElement("tr");
       nouvelleLigne.classList.add("line");

       const cellules = ["image", "nom", "prenom", "email", "sexe", "telephone", "referentiel"];
       cellules.forEach(function (prop) {
         const nouvelleCellule = document.createElement("td");
         nouvelleCellule.classList.add("bloc");
         const nouvelleDiv = document.createElement("div");
         nouvelleDiv.classList.add("col-bas");

         if (prop === "image") {
           const imgElement = document.createElement("img");
           imgElement.classList.add("profile-image");
           imgElement.src = apprenant[prop];
           imgElement.alt = "Photo de l'apprenant";
           nouvelleDiv.appendChild(imgElement);
         } else {
           nouvelleDiv.textContent = apprenant[prop];
         }
         nouvelleCellule.appendChild(nouvelleDiv);
         nouvelleLigne.appendChild(nouvelleCellule);
       });

       tableauApprenants.appendChild(nouvelleLigne);
     });
   }




 console.log('ddddddddd');
  const promo=document.getElementById('promo');
  promo.addEventListener('click',()=>{
  document.querySelector('.container').style.display='none';
  document.getElementById('Pro').style.display='';
  console.log('jjjj');
  });




  document.getElementById('app').addEventListener('click',()=>{
   document.getElementById('Pro').style.display='none';
   document.querySelector('.container').style.display='';


  })











   // Fonction pour gérer le clic sur le bouton "Suivant"
   document.getElementById('next').addEventListener('click', () => {
     const totalPages = Math.ceil(DB.etudiants.length / apprenantsParPage);
     if (pageActuelle < totalPages) {
       pageActuelle++;
       afficherApprenants();
     }
   });

   // Fonction pour gérer le clic sur le bouton "Précédent"
   document.getElementById('prev').addEventListener('click', () => {
     if (pageActuelle > 1) {
       pageActuelle--;
       afficherApprenants();
     }
   });

   // Afficher les apprenants initiaux lors du chargement de la page
   afficherApprenants();
 });

const pagine=document.getElementById('pagination');
 const v=pagine.innerHTML='<a href="#" class="page-link active">0</a>';
 console.log(pagine);



function generatePaginationLinks() {
   let paginationLinks = "";
   const totalRecords = DB.apprenant.length; // Get total number of records
   const totalPages = Math.ceil(totalRecords / learnersPerPage);
 
   for (let i = 1; i <= totalPages; i++) {
     if (i === currentPage) {
       paginationLinks += `<a href="#" class="page-link active">${i}</a>`;
     } else {
       paginationLinks += `<a href="#" class="page-link" data-page="${i}">${i}</a>`;
     }
   }
   return paginationLinks;
 }
 













