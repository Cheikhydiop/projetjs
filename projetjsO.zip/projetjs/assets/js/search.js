export const search=(tableauGlobalInitial )=>{
    
    let tableauGlobalInitial = [...DB.etudiants]; 
document.getElementById('searchGlobal').addEventListener('input', (e) => {
    let valeurSaisie = e.target.value.trim();
    let nouvelleTailleSaisie = valeurSaisie.length; 
 
    if (nouvelleTailleSaisie > 2) {
        const tableFilter = DB.etudiants.filter((item) => {
            return (
 
            
             item.nom.toLowerCase().includes(valeurSaisie.toLowerCase()) || item.prenom.toLowerCase().includes(valeurSaisie.toLowerCase())
            );
            
    
        });
        
        DB.etudiants = tableFilter;
 
        console.log(DB.etudiants);
        console.log(nouvelleTailleSaisie);
 
        afficherApprenants();
    } else if (nouvelleTailleSaisie < ancienneTailleSaisie) {
       
        DB.etudiants = [...tableauGlobalInitial]; 
 
        console.log(DB.etudiants);
        console.log(nouvelleTailleSaisie);
 
        afficherApprenants();
    }
 
    
    ancienneTailleSaisie = nouvelleTailleSaisie;
 });
}