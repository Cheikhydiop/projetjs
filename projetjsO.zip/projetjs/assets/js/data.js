export const data=(()=>{


    return(

         {
            etudiants: [
               {
                  id_etudiant: 1,
                  image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
                  prenom: "Sarre",
                  nom: "Doudou",
                  telephone: "771221903",
                  date_naissance: "2023-02-01",
                  numero_carte_identite: "222222222222",
                  sexe: "M",
                  lieuNaissance: "Thies",
                  referentiel: 1,
                  id_promo: 1
               },
               {
                  id_etudiant: 2,
                  image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
                  prenom: "Cisse",
                  nom: "Modou",
                  telephone: "771230978",
                  date_naissance: "1999-05-15",
                  numero_carte_identite: "000000000",
                  sexe: "F",
                  lieu_naissance: "Dakar",
                  referentiel: 2,
                  id_promo: 2
               },
                {
                  id_etudiant: 3,
                  image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
                  prenom: "Kane",
                  nom: "Karim",
                  telephone: "771230978",
                  date_naissance: "1999-05-15",
                  numero_carte_identite: "11111111111",
                  sexe: "F",
                  lieu_naissance: "Dakar",
                  referentiel: 2,
                  id_promo: 2
               },
               {
                  id_etudiant: 1,
                  image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
                  prenom: "warr",
                  nom: "Abdou",
                  telephone: "771221903",
                  date_naissance: "2023-02-01",
                  numero_carte_identite: "222222222222",
                  sexe: "M",
                  lieuNaissance: "Thies",
                  referentiel: 1,
                  id_promo: 1
               },
               {
                  id_etudiant: 2,
                  image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
                  prenom: "Cisse",
                  nom: "Modou",
                  telephone: "771230978",
                  date_naissance: "1999-05-15",
                  numero_carte_identite: "000000000",
                  sexe: "F",
                  lieu_naissance: "Dakar",
                  referentiel: 2,
                  id_promo: 2
               },
                {
                  id_etudiant: 3,
                  image: "https://cdn-icons-png.flaticon.com/128/3135/3135715.png",
                  prenom: "Ibou",
                  nom: "Ba",
                  telephone: "771230978",
                  date_naissance: "1999-05-15",
                  numero_carte_identite: "11111111111",
                  sexe: "F",
                  lieu_naissance: "Dakar",
                  referentiel: 2,
                  id_promo: 2
               }
            ],
            promotions: [
               {
                  id_promo: 1,
                  libelle: "Promotion 2023",
                  id_referentiel: 1
               },
               {
                  id_promo: 2,
                  libelle: "Promotion 2022",
                  id_referentiel: 2
               }
            ],
            referentiels: [
               {
                  nom: "Informatique",
                  id_referentiel: 1,
                  id_promo: 1,
                  etat: "actif"
               },
               {
                  nom: "Biologie",
                  id_referentiel: 2,
                  id_promo: 2,
                  etat: "actif"
               }
            ]
         }
    )


 
    
})
