
export const paginate=()=>{

document.addEventListener('DOMContentLoaded', () => {
    let pageActuelle = 1;
    const apprenantsParPage = 2; // Nombre d'apprenants à afficher par page
    const tableauApprenants = document.querySelector(".line5 tbody");
    let tableauGlobalInitial = [...DB.etudiants];
 
    // Fonction pour afficher les apprenants de la page actuelle
    function afficherApprenants() {
      tableauApprenants.innerHTML = "";
 
      const debut = (pageActuelle - 1) * apprenantsParPage;
      const fin = debut + apprenantsParPage;
      const apprenantsPage = DB.etudiants.slice(debut, fin);
 
      apprenantsPage.forEach(function (apprenant) {
        const nouvelleLigne = document.createElement("tr");
        nouvelleLigne.classList.add("line");
 
        const cellules = ["image", "nom", "prenom", "email", "sexe", "telephone", "referentiel"];
        cellules.forEach(function (prop) {
          const nouvelleCellule = document.createElement("td");
          nouvelleCellule.classList.add("bloc");
          const nouvelleDiv = document.createElement("div");
          nouvelleDiv.classList.add("col-bas");
 
          if (prop === "image") {
            const imgElement = document.createElement("img");
            imgElement.classList.add("profile-image");
            imgElement.src = apprenant[prop];
            imgElement.alt = "Photo de l'apprenant";
            nouvelleDiv.appendChild(imgElement);
          } else {
            nouvelleDiv.textContent = apprenant[prop];
          }
          nouvelleCellule.appendChild(nouvelleDiv);
          nouvelleLigne.appendChild(nouvelleCellule);
        });
 
        tableauApprenants.appendChild(nouvelleLigne);
      });
    }
 
    // Fonction pour gérer le clic sur le bouton "Suivant"
    document.getElementById('next').addEventListener('click', () => {
      const totalPages = Math.ceil(DB.etudiants.length / apprenantsParPage);
      if (pageActuelle < totalPages) {
        pageActuelle++;
        afficherApprenants();
      }
    });
 
    // Fonction pour gérer le clic sur le bouton "Précédent"
    document.getElementById('prev').addEventListener('click', () => {
      if (pageActuelle > 1) {
        pageActuelle--;
        afficherApprenants();
      }
    });
 
    // Afficher les apprenants initiaux lors du chargement de la page
    afficherApprenants();
  });
 
 const pagine=document.getElementById('pagination');
  const v=pagine.innerHTML='<a href="#" class="page-link active">0</a>';
  console.log(pagine);
 
 
 
 function generatePaginationLinks() {
    let paginationLinks = "";
    const totalRecords = DB.apprenant.length; // Get total number of records
    const totalPages = Math.ceil(totalRecords / learnersPerPage);
  
    for (let i = 1; i <= totalPages; i++) {
      if (i === currentPage) {
        paginationLinks += `<a href="#" class="page-link active">${i}</a>`;
      } else {
        paginationLinks += `<a href="#" class="page-link" data-page="${i}">${i}</a>`;
      }
    }
    return paginationLinks;
  }
  

}